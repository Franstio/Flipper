﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FVMI_INSPECTION.Models.ViewData
{
    public class ProcessRecordModel
    {
        public string Area { get; set; } = string.Empty;
        public string Judgement { get; set; } = string.Empty;
        public ProcessRecordModel() { }
        
    }
}
